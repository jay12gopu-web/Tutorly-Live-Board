export type CreatedBy = 'student' | 'tutorly';
export type BoardLayer = 'StudentLayer' | 'TutorlyLayer';
export type AnimationKind = 'line' | 'arc' | 'point' | 'label' | 'highlight' | 'plot';
export type AnimationSpec = { kind: AnimationKind; duration?: number; delay?: number };
export type ToolId =
  | 'select' | 'pen' | 'highlighter' | 'point' | 'line' | 'ray' | 'arrow'
  | 'circle' | 'arc' | 'rectangle' | 'text' | 'equation' | 'eraser' | 'axes' | 'graph';

export type Point = { x: number; y: number };
export type CoordinateMap = Record<string, any>;
export type BoardStyle = { stroke?: string; strokeWidth?: number; opacity?: number };

export type GraphConfig = {
  x: number;
  y: number;
  width: number;
  height: number;
  xMin: number;
  xMax: number;
  yMin: number;
  yMax: number;
  xStep?: number;
  yStep?: number;
  xLabel?: string;
  yLabel?: string;
};

export type SafeFunctionSpec =
  | { kind: 'linear'; m: number; b: number }
  | { kind: 'quadratic'; a: number; b: number; c: number };

export type BoardObject = {
  id: string;
  type: string;
  createdBy: CreatedBy;
  coordinates: CoordinateMap;
  label: string;
  stroke?: string;
  strokeWidth?: number;
  opacity?: number;
  layer: BoardLayer;
  animation?: AnimationSpec;
};

export type PointObject = BoardObject & { type: 'point'; coordinates: { x: number; y: number } };
export type SegmentObject = BoardObject & { type: 'line' | 'ray' | 'arrow'; coordinates: { x1: number; y1: number; x2: number; y2: number } };
export type CircleObject = BoardObject & { type: 'circle'; coordinates: { cx: number; cy: number; r: number } };
export type ArcObject = BoardObject & { type: 'arc'; coordinates: { cx: number; cy: number; r: number; startAngle: number; endAngle: number } };
export type RectangleObject = BoardObject & { type: 'rectangle'; coordinates: { x: number; y: number; width: number; height: number } };
export type PathObject = BoardObject & { type: 'path' | 'highlight'; coordinates: { points: Point[] } };
export type TextObject = BoardObject & { type: 'text' | 'equation'; coordinates: { x: number; y: number; text: string; fontSize: number } };
export type AxesObject = BoardObject & { type: 'axes' | 'graph'; coordinates: GraphConfig & { step?: number } };

export type AnyBoardObject =
  | PointObject | SegmentObject | CircleObject | ArcObject | RectangleObject
  | PathObject | TextObject | AxesObject;

export type BoardViewport = { zoom: number; panX: number; panY: number };
export type FocusArea = { x: number; y: number; width: number; height: number; padding?: number };

export type BoardState = {
  objects: AnyBoardObject[];
  viewport: BoardViewport;
};

type VisualPayload = { createdBy?: CreatedBy; style?: BoardStyle };

export type BoardCommand =
  | { type: 'draw_point'; payload: VisualPayload & { x: number; y: number; label?: string } }
  | { type: 'draw_line' | 'draw_ray' | 'draw_arrow'; payload: VisualPayload & { x1: number; y1: number; x2: number; y2: number; label?: string } }
  | { type: 'draw_circle'; payload: VisualPayload & { cx: number; cy: number; r: number; label?: string } }
  | { type: 'draw_arc'; payload: VisualPayload & { cx: number; cy: number; r: number; startAngle: number; endAngle: number; label?: string } }
  | { type: 'draw_rectangle'; payload: VisualPayload & { x: number; y: number; width: number; height: number; label?: string } }
  | { type: 'draw_text'; payload: VisualPayload & { x: number; y: number; text: string; fontSize?: number; equation?: boolean } }
  | { type: 'draw_axes' | 'draw_graph'; payload?: VisualPayload & Partial<GraphConfig> & { step?: number } }
  | { type: 'plot_point'; payload: VisualPayload & { graph: GraphConfig; xValue: number; yValue: number; label?: string } }
  | { type: 'plot_function'; payload: VisualPayload & { graph: GraphConfig; fn: SafeFunctionSpec; domain?: { min: number; max: number }; samples?: number; label?: string } }
  | { type: 'draw_number_line'; payload: VisualPayload & { x: number; y: number; width: number; min: number; max: number; step?: number; interval?: { from: number; to: number; fromClosed: boolean; toClosed: boolean }; label?: string } }
  | { type: 'highlight'; payload: VisualPayload & { points: Point[]; label?: string } }
  | { type: 'draw_path'; payload: VisualPayload & { points: Point[]; label?: string } }
  | { type: 'move_object'; payload: { id: string; dx: number; dy: number } }
  | { type: 'delete_object'; payload: { id: string } }
  | { type: 'clear_board' }
  | { type: 'clear_student_layer' }
  | { type: 'zoom_to'; payload: { zoom?: number; panX?: number; panY?: number } }
  | { type: 'focus_objects'; payload: { objectIds?: string[]; area?: FocusArea; padding?: number } };

export const isDrawableObject = (object: AnyBoardObject) =>
  !['axes', 'graph'].includes(object.type);
